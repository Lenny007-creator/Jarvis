import sys
import argparse
from modules.voice import VoiceAssistant
from modules.core import JarvisCore
from utils.logger import log

def parse_args():
    parser = argparse.ArgumentParser(description="Leandro’s Personal AI – Inspired by J.A.R.V.I.S.")
    parser.add_argument('--voice', action='store_true', help='Starte Sprachmodus')
    parser.add_argument('--text', action='store_true', help='Starte Textmodus (CLI)')
    return parser.parse_args()

def main():
    args = parse_args()
    log("Starte KI-Assistent...")

    # Initialisiere Kernlogik
    jarvis = JarvisCore()

    if args.voice:
        log("Sprachmodus aktiviert.")
        assistant = VoiceAssistant(jarvis)
        assistant.run()

    elif args.text:
        log("Textmodus aktiviert.")
        print(">> Schreibe 'exit' zum Beenden.")
        while True:
            try:
                user_input = input("🧠 Du: ")
                if user_input.lower() in ['exit', 'quit']:
                    break
                response = jarvis.process(user_input)
                print(f"🤖 Jarvis: {response}")
            except KeyboardInterrupt:
                break

    else:
        print("❗ Bitte Modus angeben: --voice oder --text")

if __name__ == '__main__':
    main()
